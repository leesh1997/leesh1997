package gagame;

import java.util.concurrent.TimeUnit;

public class function {
	public void timelate(int a) {
		try {
			TimeUnit.SECONDS.sleep(a);
		} catch (Exception e) {
		}

	}

}
